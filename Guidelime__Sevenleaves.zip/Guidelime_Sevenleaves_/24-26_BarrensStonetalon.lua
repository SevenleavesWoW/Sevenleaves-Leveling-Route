﻿Guidelime.registerGuide([[
[DL1-60 https://www.curseforge.com/wow/addons/sevenleaves-guidelime-route Guidelime_Sevenleaves]
[D |cffffffffA Guide made by|r |cffffff00Sevenleaves|r and |cffffff00Tactics|r \\ |cff00E5EEtwitch.tv/7leaves|r \\ |cff00E5EEtwitch.tv/tactics_lol|r \\ |cff00E5EEhttps://discordapp.com/invite/YgXQZj6|r]
[N24-26 Barrens/Stonetalon]
[GA Horde]




Deliver the quest [G87.96,48.28Desolace][QT1067 Return to Thunderbluff] and accept [G87.96,48.28Desolace][QA1086 The Flying Machine Airport]
[F]Fly to Camp T.
Take the quests [G44.54,59.26The Barrens][QA879 Betrayal From Within] & [G45.1,57.68The Barrens][QA893 Weapons of Choice] and turn the rest of your Blood Shards in for buffs.

Razorhide (4 shards) buff is highly recommended for this next quest[OC]
Run south and do [G51.06,29.62The Barrens][QA868 Egg Hunt], you need to loot the Silithid Mound for Silithid Egg
Kill the rare mob Silithid Harvester if it's up, it drops the quest [QS897The Harvester][O]
Walk further south and accept the quest [G45.89,77The Barrens][QA843 Gann's Reclamation]. 

Go and do the quest [G41.84,80.06The Barrens][QC893 Weapons of Choice] & [G45.17,80.32The Barrens][QC879 Betrayal from Within] by killing the different Quilboar mobs, to get Razormane Backstabber, Razormane Wand and Razormane War Shield. You will also need to kill Kuz, Nak and Lok for their skulls.
Kill the mob Washte Pawne, it drops the quest [G43.18,80.92The Barrens][QA885 Washte Pawne].
After go and complete [G45.89,77The Barrens][QA843 Gann's Reclamation], you will have to kill Bel’dun Excavator and Bael’dun Foreman and a higher level mob at the very back called Prospector Khazgorm for Khazgorm’s Journal. 
Walk back to the road and find Gann Stonespire to turn in [G45.89,77The Barrens][QT843 Gann's Reclamation].
Avoid the Bael’dun Officers in the next quests.[OC]
Take the new quest [G45.89,77The Barrens][QA846 Revenge Of Gann], go and complete the quest by killing Bael’dun Soldier and Bael’dun Rifleman.
Deliver [G45.89,77The Barrens][QT846 Revenge Of Gann] and accept [G45.89,77The Barrens][QA849 Revenge of Gann part 2]
Go and destroy the airplane, then walk back and deliver [G45.89,77The Barrens][QT849 Revenge of Gann part 2].
Walk into Dustwallow Marsh and die on purpose.[OC]
Buy health potions and scrolls, Manual: Heavy Silk Bandage, Manual: Mageweave Bandage, Expert FIrst Aid - Under Wraps from Balai Lok’Wein[OC]
[F]Fly to Camp T and deliver the quests [G44.54,59.26The Barrens][QT879 Betrayal From Within] & accept [G44.54,59.26The Barrens][QA906 Betrayal From Within part 2]. Turn in[G44.85,59.13The Barrens][QT885 Washte Pawne]
Turn in [G45.1,57.68The Barrens][QT893 Weapons of Choice] 
[O]Turn in [G44.85,59.13The Barrens][QT897 The Harvester] if you were lucky enough to get the rare.
[F]Fly to The Crossroads and deliver Egg Hunt(1750 exp) and Betrayal From Within(3050 exp) part 2. & make [S The Crossroads] your hearth.
[F]Fly to Ratchet and go deliver the quest Mahren Skyseer at the shore near the pirates.
Accept the quest [G65.83,43.85The Barrens][QA873 Isha Awak] and go follow the coast south to kill [G63.52,53.85The Barrens][QC873 Isha Awak] and loot her.
Go back and deliver the quest [G65.83,43.85The Barrens][QT873 Isha Awak] and [H hearth to The Crossroads]
[F]Fly to Sun Rock Retreat in Stonetalon Mountains.





Pick up all the quests in Sunrock Retreat, [G16.72,8.83The Barrens][QA6381 New Life], [G16.59,10.17The Barrens][QA6282 Harpies Threaten], [G15.99,9.81The Barrens][QA1087 Cenarius' Legacy] and last [G16.67,11.68The Barrens][QA6393 Elemental War] on the mountain.
Go north and start picking up Gaea Seed near the lake for the quest [G8.89,14.37The Barrens][QC6381 New Life].
Walk further north and do the 2 quests [G6.72,54.06Ashenvale][QC1058 Jin'Zil's Forest Magic] and [G4.11,56.56Ashenvale][QC1087 Cenarius' Legacy], you will have to kill these mobs for these 2 quests. Sap Beast, Twilight Runner, Antlered Courser, Fey Dragon, Son of Cenarius, Daughter of Cenarius, Cenarion Botanist.
Start walking south, if you didn’t get all 10 Geea Seeds, get the last ones now.[OC]
Walk into the Vale from the path at the lake to do the quest [G10.84,12.99The Barrens][QC6282 Harpies Threaten], kill the Fire Elementals too whenever you see them.
Walk back to Sunrock Retreat and deliver [G15.99,9.81The Barrens][QT1087 Cenarius' Legacy], [G16.59,10.17The Barrens][QT6282 Harpies Threaten] and [G16.72,8.83The Barrens][QT6381 New Life] and accept the new quests [G15.99,9.81The Barrens][QA1088 Ordanus], [G16.59,10.17The Barrens][QA6283 Bloodfury Bloodline] and [G16.72,8.83The Barrens][QA6301 Cycle of Rebirth]
Walk back to the Vale and finish [G9.13,16.04The Barrens][QC6393 Elemental War] and start doing [G17.76,1.82The Barrens][QC6301 Cycle of Rebirth]. Then go and kill [G8.67,10.53The Barrens][QC6283 Bloodfury Ripper], when she enrages she walks really slow, use this to get lots of throwns in and energy back whenever gouge is up.
Go back and deliver the quests [G16.67,11.68The Barrens][QT6393 Elemental War], [G16.72,8.83The Barrens][QT6301 Cycle of Rebirth] and [G16.59,10.17The Barrens][QT6283 Bloodfury Bloodline]. Accept [G16.59,10.17The Barrens][QA5881 Calling In The Reserves].
Walk over to Ziz Fizziks and accept [G22.28,10.86The Barrens][QA1096 Gerenzo Wrenchwhistle].
Complete the quest [G24.76,3.04The Barrens][QC1068 Shredding Machines], [QC1086The Flying Machine Airport] and [G24.92,0.09The Barrens][QC1096 Gerenzo Wrenchwhistle].
Deliver the quest [G22.28,10.86The Barrens][QT1096 Gerenzo Wrenchwhistle] and walk over to Wanted Poster: Besseleth and accept [G86.11,0.01Desolace][QA6284 Arachnophobia].
Accept Wanted poster: Besseleth and go in and kill the elite [G18.89,16.29The Barrens][QC6284 Besseleth] 
Walk south and deliver [G29.77,27.89The Barrens][QT1058 Jin'zil's Forest Magic] & [G35.26,27.86The Barrens][QT1068 Shredding Machines] at the entrance of Stonetalon. 
Hearth to[H The Crossroads] and fly to [F Eastern Ashenvale]







[NX26-28 Ashenvale & BFD Solo]


]],"Tactics/Sevenleaves' Leveling Guide")