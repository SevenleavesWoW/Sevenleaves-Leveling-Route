﻿Guidelime.registerGuide([[
[DL1-60 https://www.curseforge.com/wow/addons/sevenleaves-guidelime-route Guidelime_Sevenleaves]
[D |cffffffffA Guide made by|r |cffffff00Sevenleaves|r and |cffffff00Tactics|r \\ |cff00E5EEtwitch.tv/7leaves|r \\ |cff00E5EEtwitch.tv/tactics_lol|r \\ |cff00E5EEhttps://discordapp.com/invite/YgXQZj6|r]
[N22-24 Hillsbrad]
[GA Horde]

Walk into Hillsbrad and take the quest [G20.78,47.4Hillsbrad Foothills][QA494 Time to Strike] at the tower when you first arrive. 
Walk to Tarren mill & deliver [G60.31,80.85Alterac Mountains][QT2479 Hinott’s Assistance][A Rogue] & accept [G60.31,80.85Alterac Mountains][QA2480 Hinott’s Assistance Part 2][A Rogue]
While waiting for the short RP to finish from Hinott’s Assistance part 2, deliver the quests [QT493 Journey to Hillsbrad Foothills] & [QT1065 Journey to Tarren Mill]. accept [QA1066 Blood of Innocents], [G60.09,80.71Alterac Mountains][QA496 Elixir of Suffering] & [G60.09,80.71Alterac Mountains][QA501 Elixir of Pain]
Deliver [G60.31,80.85Alterac Mountains][QT2480 Hinott’s Assistance Part 2][A Rogue] and drink Hinott's Oil & make some Instant Poisons
Deliver [G61.11,82.3Alterac Mountains][QT494 Time to Strike] & accept [G61.11,82.3Alterac Mountains][QA527 Battle of Hillsbrad Part 1]
Walk over to Melisara and click the WANTED poster to accept [G61.46,82.64Alterac Mountains][QA549 WANTED: Syndicate Personnel]
Walk inside the building and take [G62.15,82.53Alterac Mountains][QA498 The Rescue] from Krusk.
Lastly, run to the Inn and take the quest [G61.37,81.4Alterac Mountains][QA567 Dangerous!] from the WANTED poster
After walk over and complete [G17.84,16.25Arathi Highlands][QC549 Wanted: Syndicate Personnel], [QC1066 Blood of Innocents] and [G15.23,13.84Arathi Highlands][QC498 The Rescue]


[V]Buy BOE bracers and pants from Kris Legace[G 80.2,39 Hillsbrad Foothills] behind the Jailor’s location.[OC]
When the 3 quests are done go out and start on Elixir of Suffering make sure to get Creeper Ichor and farm a few Gray Bear Tongues[OC]
Run back to Tarren Mill and turn in [G62.15,82.53Alterac Mountains][QT498 The Rescue], [G61.11,82.3Alterac Mountains][QT549 WANTED: Syndicate Personnel], [QT1066 Blood of Innocents]. Accept [G60.86,81.44Alterac Mountains][QA546 Souvenirs of Death]



Head west towards Battle for Hillsbrad & kill all the Lions and Bears you can on the way towards Elixir of Pain and Elixir of Suffering.[OC]
Do [G33.87,38.98Hillsbrad Foothills][QC527 Battle of Hillsbrad Part 1]
Run back to Tarren Mill. Make sure to finish both quests [G33.46,84.73Alterac Mountains][QC501 Elixir of Pain] and [G36.76,54.21Hillsbrad Foothills][QC496 Elixir of Suffering] before you arrive.
Turn in [G61.11,82.3Alterac Mountains][QT527 Battle for Hillsbrad Part 1] & accept [G61.11,82.3Alterac Mountains][QA528 Battle of Hillsbrad Part 2] 
Turn in [G60.09,80.71Alterac Mountains][QT501 Elixir of Pain] and [G60.09,80.71Alterac Mountains][QT496 Elixir of Suffering]
Accept [G60.09,80.71Alterac Mountains][QA502 Elixir of Suffering Part 2]and [G27.21,99.29Alterac Mountains][QT502 turn it in] to Umpi. Accept Elixir of Pain part 2 as well.




Head back and kill 15 Hillsbrad Peasants for [G34.3,45.23Hillsbrad Foothills][QC528 Battle of Hillsbrad Part 2]. You don’t need to complete Souvenirs of Death yet.
Remember to kill Stanley for EXP after he transformed[OC]
Walk up to the northern part of the farms and give Stanley the potion to complete [QC502 Elixir of Pain Part 2].

Deliver [G61.11,82.3Alterac Mountains][QT528 Battle of Hillsbrad Part 2] and accept [G61.11,82.3Alterac Mountains][QA529 Battle of Hillsbrad Part 3]
Go over and kill the Blacksmiths for [G31.81,45.33Hillsbrad Foothills][QC529 Battle of Hillsbrad Part 3]. When the quest is done, die on purpose and [G61.11,82.3Alterac Mountains][QT529 deliver the quest]
Walk over to [V]Ott[G 60.4,26.2] and buy a Broad Bladed Knife.[OC]
[F]Fly to Sepulcher and deliver [G43.97,40.93Silverpine Forest][QT480 The Weaver] and [G43.97,40.93Silverpine Forest][QT516 Beren’s Peril]
Now [F]fly to Undercity and deliver [G62.01,42.74Undercity][QT530 A Husband’s Revenge] 
[T]Train your level 24 spells and use [H]Hearth to Thunder Bluff.





[NX24-26 Barrens/Stonetalon]


]],"Tactics/Sevenleaves' Leveling Guide")