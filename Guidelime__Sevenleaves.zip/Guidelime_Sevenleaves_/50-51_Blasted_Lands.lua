Guidelime.registerGuide([[
[DL1-60 https://www.curseforge.com/wow/addons/sevenleaves-guidelime-route Guidelime_Sevenleaves]
[D |cffffffffA Guide made by|r |cffffff00Sevenleaves|r and |cffffff00Tactics|r \\ |cff00E5EEtwitch.tv/7leaves|r \\ |cff00E5EEtwitch.tv/tactics_lol|r \\ |cff00E5EEhttps://discordapp.com/invite/YgXQZj6|r]
[N50-51 Blasted Lands]
[GA Horde]

Deliver [G47.93,54.77Swamp of Sorrows][QT1444 Return to Fel'Zerul]
Accept [G34.28,66.14Swamp of Sorrows][QA2784 Fall From Grace] \\Talk to him and complete [G34.28,66.14Swamp of Sorrows][QC2784 Fall From Grace] \\Deliver [G34.28,66.14Swamp of Sorrows][QT2784 Fall From Grace] \\Accept [G34.28,66.14Swamp of Sorrows][QA2621 The Disgraced One]

Deliver [G47.78,54.93Swamp of Sorrows][QT2621 The Disgraced One] \\Accept [G47.78,54.93Swamp of Sorrows][QA2622 The Missing Orders] \\Deliver [G44.96,57.36Swamp of Sorrows][QT2622 The Missing Orders] \\Accept [G44.96,57.36Swamp of Sorrows][QA2623 The Swamp Talker]

Walk down to the Murloc cave[G65,77Swamp of Sorrows]
Then head towards the very back of it to kill Swamp Talker to complete [G62.6,88.07Swamp of Sorrows][QC2623 The Swamp Talker]
Deliver [G34.28,66.14Swamp of Sorrows][QT2623 The Swamp Talker] \\Accept [G34.28,66.14Swamp of Sorrows][QA2801 A Tale of Sorrow] \\Talk to him and deliver [G34.28,66.14Swamp of Sorrows][QT2801 A Tale of Sorrow]

Walk south and accept the following: \\[G31.18,82.73Swamp of Sorrows][QA2601 The Basilisk's Bite] \\[G31.18,82.73Swamp of Sorrows][QA2603 Vulture's Vigor] \\[G31.04,82.59Swamp of Sorrows][QA2581 Snickerfang Jowls] \\[G31.04,82.59Swamp of Sorrows][QA2583 A Boar's Vitality] \\[G31.04,82.59Swamp of Sorrows][QA2585 The Decisive Striker]
Complete the following: \\[G83.6,5.99,148Stranglethorn Vale][QC2601 The Basilisk's Bite] \\[G82.52,6.56,171Stranglethorn Vale][QC2603 Vulture's Vigor] \\[G25.61,89.71,161Swamp of Sorrows][QC2581 Snickerfang Jowls] \\[G86.13,0.75,175Stranglethorn Vale][QC2583 A Boar's Vitality] \\[G28.88,89.99,124Swamp of Sorrows][QC2585 The Decisive Striker]
Walk back and deliver them all: \\[G31.18,82.73Swamp of Sorrows][QT2601 The Basilisk's Bite] \\[G31.18,82.73Swamp of Sorrows][QT2603 Vulture's Vigor] \\[G31.04,82.59Swamp of Sorrows][QT2581 Snickerfang Jowls] \\[G31.04,82.59Swamp of Sorrows][QT2583 A Boar's Vitality] \\[G31.04,82.59Swamp of Sorrows][QT2585 The Decisive Striker]

Walk back to Stonard and [F]fly to Badlands[OC]

[NX51-52 Searing Gorge]

]],"Tactics/Sevenleaves' Leveling Guide")